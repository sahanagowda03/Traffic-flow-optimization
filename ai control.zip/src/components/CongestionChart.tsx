import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { useTheme } from '../context/ThemeContext';

interface CongestionChartProps {
  data: { timestamp: number; level: number }[];
}

export const CongestionChart: React.FC<CongestionChartProps> = ({ data }) => {
  const { isDarkMode } = useTheme();
  
  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="h-40 w-full">
      <ResponsiveContainer>
        <LineChart data={data}>
          <XAxis 
            dataKey="timestamp" 
            tickFormatter={formatTime}
            stroke={isDarkMode ? '#9CA3AF' : '#4B5563'}
          />
          <YAxis 
            domain={[0, 100]}
            stroke={isDarkMode ? '#9CA3AF' : '#4B5563'}
          />
          <Tooltip
            labelFormatter={formatTime}
            contentStyle={{
              backgroundColor: isDarkMode ? '#1F2937' : '#FFFFFF',
              border: 'none',
              borderRadius: '0.375rem',
            }}
          />
          <Line 
            type="monotone" 
            dataKey="level" 
            stroke="#3B82F6" 
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};