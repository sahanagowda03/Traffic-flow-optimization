import React, { useState, useEffect } from 'react';
import { Activity, Moon, Sun } from 'lucide-react';
import { IntersectionCard } from './components/IntersectionCard';
import { initialIntersections } from './data/mockData';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import type { Intersection } from './types/traffic';
import { motion } from 'framer-motion';

function AppContent() {
  const [intersections, setIntersections] = useState<Intersection[]>(initialIntersections);
  const [isEmergencyMode, setIsEmergencyMode] = useState(false);
  const { isDarkMode, toggleDarkMode } = useTheme();

  // Handle emergency vehicle detection
  useEffect(() => {
    const hasEmergency = intersections.some(int => int.hasEmergencyVehicle);
    setIsEmergencyMode(hasEmergency);

    if (hasEmergency) {
      setIntersections(current =>
        current.map(intersection => ({
          ...intersection,
          currentLight: intersection.hasEmergencyVehicle ? 'GREEN' : 'RED'
        }))
      );

      // Resume normal traffic after 5 seconds
      const timer = setTimeout(() => {
        setIntersections(current =>
          current.map(intersection => ({
            ...intersection,
            hasEmergencyVehicle: false,
            waitingVehicles: intersection.currentLight === 'GREEN' 
              ? Math.max(0, intersection.waitingVehicles - Math.floor(Math.random() * 3))
              : intersection.waitingVehicles
          }))
        );
        setIsEmergencyMode(false);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [intersections.map(int => int.hasEmergencyVehicle).join(',')]);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isEmergencyMode) {
        setIntersections((current) =>
          current.map((intersection) => {
            const newCongestionLevel = Math.min(
              100,
              Math.max(0, intersection.congestionLevel + (Math.random() * 20 - 10))
            );
            
            const newWaitingVehicles = intersection.currentLight === 'GREEN'
              ? Math.max(0, intersection.waitingVehicles - Math.floor(Math.random() * 3))
              : Math.max(0, intersection.waitingVehicles + Math.floor(Math.random() * 2));
            
            return {
              ...intersection,
              congestionLevel: newCongestionLevel,
              waitingVehicles: newWaitingVehicles,
              congestionHistory: [
                ...intersection.congestionHistory.slice(1),
                { timestamp: Date.now(), level: newCongestionLevel }
              ]
            };
          })
        );
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [isEmergencyMode]);

  const handleLightChange = (id: string, newStatus: 'RED' | 'YELLOW' | 'GREEN') => {
    if (!isEmergencyMode) {
      setIntersections((current) =>
        current.map((intersection) =>
          intersection.id === id
            ? { ...intersection, currentLight: newStatus }
            : intersection
        )
      );
    }
  };

  const handleEmergencyToggle = (id: string) => {
    if (!isEmergencyMode || intersections.find(int => int.id === id)?.hasEmergencyVehicle) {
      setIntersections((current) =>
        current.map((intersection) =>
          intersection.id === id
            ? { ...intersection, hasEmergencyVehicle: !intersection.hasEmergencyVehicle }
            : intersection
        )
      );
    }
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
      <div className="container mx-auto px-4 py-8">
        <motion.div 
          className="flex justify-between items-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4">
            <Activity className={`w-8 h-8 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
            <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
              Traffic Control System
            </h1>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-lg ${
              isDarkMode 
                ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' 
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
          </button>
        </motion.div>

        {isEmergencyMode && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`mb-6 p-4 rounded-lg ${
              isDarkMode ? 'bg-red-900 text-red-100' : 'bg-red-100 text-red-800'
            }`}
          >
            <p className="font-semibold">🚨 Emergency Vehicle Detected</p>
            <p className="text-sm">Traffic signals adjusted for emergency response</p>
          </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {intersections.map((intersection) => (
            <IntersectionCard
              key={intersection.id}
              intersection={intersection}
              onLightChange={handleLightChange}
              onEmergencyToggle={handleEmergencyToggle}
              isEmergencyMode={isEmergencyMode}
            />
          ))}
        </div>

        <motion.div 
          className={`mt-8 ${
            isDarkMode ? 'bg-gray-800' : 'bg-white'
          } rounded-lg shadow-lg p-6`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className={`text-xl font-semibold mb-4 ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>System Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className={`${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
            } p-4 rounded-lg`}>
              <p className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                Total Intersections
              </p>
              <p className={`text-2xl font-bold ${
                isDarkMode ? 'text-white' : 'text-gray-800'
              }`}>
                {intersections.length}
              </p>
            </div>
            <div className={`${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
            } p-4 rounded-lg`}>
              <p className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                Total Waiting Vehicles
              </p>
              <motion.p 
                className={`text-2xl font-bold ${
                  isDarkMode ? 'text-white' : 'text-gray-800'
                }`}
                animate={{ 
                  scale: intersections.reduce((sum, int) => sum + int.waitingVehicles, 0) > 20 ? [1, 1.1, 1] : 1 
                }}
                transition={{ duration: 0.5 }}
              >
                {intersections.reduce((sum, int) => sum + int.waitingVehicles, 0)}
              </motion.p>
            </div>
            <div className={`${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
            } p-4 rounded-lg`}>
              <p className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                Average Congestion
              </p>
              <p className={`text-2xl font-bold ${
                isDarkMode ? 'text-white' : 'text-gray-800'
              }`}>
                {Math.round(
                  intersections.reduce((sum, int) => sum + int.congestionLevel, 0) /
                    intersections.length
                )}%
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;