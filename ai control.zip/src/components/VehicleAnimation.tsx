import React from 'react';
import { motion } from 'framer-motion';
import { Car, Bike, Ambulance } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface VehicleAnimationProps {
  isMoving: boolean;
  hasEmergencyVehicle: boolean;
  vehicleCount: number;
}

export const VehicleAnimation: React.FC<VehicleAnimationProps> = ({
  isMoving,
  hasEmergencyVehicle,
  vehicleCount
}) => {
  const { isDarkMode } = useTheme();
  const textColor = isDarkMode ? 'text-gray-300' : 'text-gray-600';

  const vehicles = Array.from({ length: Math.min(vehicleCount, 5) }, (_, i) => {
    const isAmbulance = hasEmergencyVehicle && i === 0;
    const Vehicle = isAmbulance ? Ambulance : i % 2 === 0 ? Car : Bike;
    
    return (
      <motion.div
        key={i}
        initial={{ x: -50, opacity: 0 }}
        animate={{
          x: isMoving ? 50 : 0,
          opacity: 1,
          scale: isAmbulance ? [1, 1.1, 1] : 1
        }}
        transition={{
          x: { duration: 1, repeat: isMoving ? Infinity : 0 },
          scale: { duration: 0.5, repeat: isAmbulance ? Infinity : 0 }
        }}
        className={`${textColor} ${isAmbulance ? 'text-red-500' : ''}`}
      >
        <Vehicle className="w-6 h-6" />
      </motion.div>
    );
  });

  return (
    <div className="flex space-x-2 overflow-hidden py-2">
      {vehicles}
    </div>
  );
};