import { Intersection } from '../types/traffic';

const generateHistory = () => {
  const history = [];
  const now = Date.now();
  for (let i = 0; i < 10; i++) {
    history.push({
      timestamp: now - (9 - i) * 60000,
      level: Math.floor(Math.random() * 100)
    });
  }
  return history;
};

export const initialIntersections: Intersection[] = [
  {
    id: '1',
    name: 'Main St & 1st Ave',
    currentLight: 'RED',
    congestionLevel: 75,
    waitingVehicles: 12,
    coordinates: { lat: 40.7128, lng: -74.0060 },
    hasEmergencyVehicle: false,
    congestionHistory: generateHistory()
  },
  {
    id: '2',
    name: 'Broadway & 5th St',
    currentLight: 'GREEN',
    congestionLevel: 45,
    waitingVehicles: 5,
    coordinates: { lat: 40.7589, lng: -73.9851 },
    hasEmergencyVehicle: false,
    congestionHistory: generateHistory()
  },
  {
    id: '3',
    name: 'Park Ave & 3rd St',
    currentLight: 'YELLOW',
    congestionLevel: 60,
    waitingVehicles: 8,
    coordinates: { lat: 40.7829, lng: -73.9654 },
    hasEmergencyVehicle: false,
    congestionHistory: generateHistory()
  }
];