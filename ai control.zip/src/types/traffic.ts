export interface Intersection {
  id: string;
  name: string;
  currentLight: 'RED' | 'YELLOW' | 'GREEN';
  congestionLevel: number; // 0-100
  waitingVehicles: number;
  coordinates: {
    lat: number;
    lng: number;
  };
  hasEmergencyVehicle: boolean;
  congestionHistory: { timestamp: number; level: number }[];
}

export interface TrafficState {
  intersections: Intersection[];
  isDarkMode: boolean;
}

export interface ThemeContextType {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}