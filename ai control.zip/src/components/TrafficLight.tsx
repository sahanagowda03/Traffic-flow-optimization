import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

interface TrafficLightProps {
  status: 'RED' | 'YELLOW' | 'GREEN';
  onStatusChange: (newStatus: 'RED' | 'YELLOW' | 'GREEN') => void;
  hasEmergencyVehicle: boolean;
  isEmergencyMode: boolean;
}

export const TrafficLight: React.FC<TrafficLightProps> = ({ 
  status, 
  onStatusChange,
  hasEmergencyVehicle,
  isEmergencyMode
}) => {
  const { isDarkMode } = useTheme();

  const getNextLight = (current: string) => {
    if (isEmergencyMode) return current;
    switch (current) {
      case 'RED': return 'GREEN';
      case 'GREEN': return 'YELLOW';
      case 'YELLOW': return 'RED';
      default: return 'RED';
    }
  };

  useEffect(() => {
    if (hasEmergencyVehicle && status !== 'GREEN') {
      onStatusChange('GREEN');
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.play();
    }
  }, [hasEmergencyVehicle, status]);

  useEffect(() => {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audio.play();
  }, [status]);

  return (
    <div className="flex flex-col items-center space-y-4">
      <motion.div 
        className={`${isDarkMode ? 'bg-gray-900' : 'bg-gray-800'} p-4 rounded-lg flex flex-col space-y-2`}
        animate={{ scale: hasEmergencyVehicle ? [1, 1.05, 1] : 1 }}
        transition={{ duration: 0.5, repeat: hasEmergencyVehicle ? Infinity : 0 }}
      >
        <motion.div 
          className={`w-8 h-8 rounded-full ${
            status === 'RED' ? 'bg-red-500' : 'bg-red-900'
          }`}
          animate={{ 
            scale: status === 'RED' ? [1, 1.1, 1] : 1,
            opacity: status === 'RED' ? 1 : 0.5
          }}
          transition={{ duration: 0.5, repeat: status === 'RED' ? Infinity : 0 }}
        />
        <motion.div 
          className={`w-8 h-8 rounded-full ${
            status === 'YELLOW' ? 'bg-yellow-400' : 'bg-yellow-900'
          }`}
          animate={{ 
            scale: status === 'YELLOW' ? [1, 1.1, 1] : 1,
            opacity: status === 'YELLOW' ? 1 : 0.5
          }}
          transition={{ duration: 0.5, repeat: status === 'YELLOW' ? Infinity : 0 }}
        />
        <motion.div 
          className={`w-8 h-8 rounded-full ${
            status === 'GREEN' ? 'bg-green-500' : 'bg-green-900'
          }`}
          animate={{ 
            scale: status === 'GREEN' ? [1, 1.1, 1] : 1,
            opacity: status === 'GREEN' ? 1 : 0.5
          }}
          transition={{ duration: 0.5, repeat: status === 'GREEN' ? Infinity : 0 }}
        />
      </motion.div>
      <button
        onClick={() => onStatusChange(getNextLight(status) as 'RED' | 'YELLOW' | 'GREEN')}
        disabled={isEmergencyMode && !hasEmergencyVehicle}
        className={`${
          isDarkMode 
            ? 'bg-blue-600 hover:bg-blue-700' 
            : 'bg-blue-500 hover:bg-blue-600'
        } text-white px-4 py-2 rounded transition-colors ${
          isEmergencyMode && !hasEmergencyVehicle ? 'opacity-50 cursor-not-allowed' : ''
        }`}
      >
        Change Light
      </button>
    </div>
  );
};