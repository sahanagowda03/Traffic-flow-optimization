import React from 'react';
import { Intersection } from '../types/traffic';
import { TrafficLight } from './TrafficLight';
import { CongestionChart } from './CongestionChart';
import { VehicleAnimation } from './VehicleAnimation';
import { Car, Ambulance } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { motion } from 'framer-motion';

interface IntersectionCardProps {
  intersection: Intersection;
  onLightChange: (id: string, newStatus: 'RED' | 'YELLOW' | 'GREEN') => void;
  onEmergencyToggle: (id: string) => void;
  isEmergencyMode: boolean;
}

export const IntersectionCard: React.FC<IntersectionCardProps> = ({
  intersection,
  onLightChange,
  onEmergencyToggle,
  isEmergencyMode,
}) => {
  const { isDarkMode } = useTheme();
  const isMoving = intersection.currentLight === 'GREEN' && !isEmergencyMode;

  return (
    <motion.div 
      className={`${
        isDarkMode ? 'bg-gray-800 text-white' : 'bg-white'
      } rounded-lg shadow-lg p-6 space-y-4`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className={`text-xl font-semibold ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>{intersection.name}</h3>
          <p className={isDarkMode ? 'text-gray-300' : 'text-gray-500'}>
            ID: {intersection.id}
          </p>
        </div>
        <TrafficLight
          status={intersection.currentLight}
          onStatusChange={(newStatus) => onLightChange(intersection.id, newStatus)}
          hasEmergencyVehicle={intersection.hasEmergencyVehicle}
          isEmergencyMode={isEmergencyMode}
        />
      </div>

      <div className={`${
        isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
      } p-4 rounded-lg`}>
        <VehicleAnimation
          isMoving={isMoving}
          hasEmergencyVehicle={intersection.hasEmergencyVehicle}
          vehicleCount={intersection.waitingVehicles}
        />
      </div>

      <div className="grid grid-cols-2 gap-4 mt-4">
        <div className={`${
          isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
        } p-4 rounded-lg`}>
          <div className="flex items-center space-x-2">
            <Car className={isDarkMode ? 'text-gray-300' : 'text-gray-600'} />
            <span className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
              Waiting Vehicles
            </span>
          </div>
          <motion.p 
            className="text-2xl font-bold"
            animate={{ scale: intersection.waitingVehicles > 10 ? [1, 1.1, 1] : 1 }}
            transition={{ duration: 0.5 }}
          >
            {intersection.waitingVehicles}
          </motion.p>
        </div>

        <div className={`${
          isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
        } p-4 rounded-lg`}>
          <div className="flex items-center justify-between">
            <span className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
              Congestion
            </span>
            <button
              onClick={() => onEmergencyToggle(intersection.id)}
              disabled={isEmergencyMode && !intersection.hasEmergencyVehicle}
              className={`${
                intersection.hasEmergencyVehicle 
                  ? 'text-red-500' 
                  : isDarkMode ? 'text-gray-300' : 'text-gray-600'
              } ${isEmergencyMode && !intersection.hasEmergencyVehicle ? 'opacity-50 cursor-not-allowed' : ''}`}
              title="Toggle emergency vehicle"
            >
              <Ambulance className="w-5 h-5" />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex-1 bg-gray-200 rounded-full h-4">
              <motion.div
                className={`h-4 rounded-full ${
                  intersection.congestionLevel > 75
                    ? 'bg-red-500'
                    : intersection.congestionLevel > 50
                    ? 'bg-yellow-500'
                    : 'bg-green-500'
                }`}
                initial={{ width: '0%' }}
                animate={{ width: `${intersection.congestionLevel}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <span className="text-sm font-medium">
              {intersection.congestionLevel}%
            </span>
          </div>
        </div>
      </div>

      <div className={`${
        isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
      } p-4 rounded-lg mt-4`}>
        <h4 className={`text-sm font-medium mb-2 ${
          isDarkMode ? 'text-gray-300' : 'text-gray-600'
        }`}>
          Congestion Trend
        </h4>
        <CongestionChart data={intersection.congestionHistory} />
      </div>
    </motion.div>
  );
};